import React from 'react'

const Login= (props)=>{
    return(
            <div>
                <h1>
                    Login Page
                </h1>
                 {console.log(props)}
                {/* <p>Name : {this.props.firstName}</p> */}
                
            </div>
        )
    
}

export default Login