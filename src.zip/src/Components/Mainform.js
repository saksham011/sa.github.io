import React from 'react';
import './App.css';
import axios from 'axios'
import {Redirect} from 'react-router-dom'
import qdoba from  './QDOBA_hor.svg'
class Mainform extends React.Component {
  constructor(){
    super()
    this.state=({
      username:"",
      password:"",
      accTok:"",
      cusId:"",
      data:{},
      loading:false,
      signUp:false,
      history:{},
      resultSet:{},
      items:[],
      amt:[],
      order:false,
      ohistory:false,
    })
    this.handleChange=this.handleChange.bind(this)
    this.handleSubmit=this.handleSubmit.bind(this)
    this.signUp=this.signUp.bind(this)
    this.handleBack=this.handleBack.bind(this)
    this.handleRet=this.handleRet.bind(this)
    this.history_handler=this.history_handler.bind(this)
  }
    handleChange(event){
    const {name,value}=event.target
    this.setState({
      [name]:value
    })
   }
   
  async handleSubmit(e){
  e.preventDefault();
	const employee = {
		username: this.state.username,
	  password: this.state.password,
		
  }
  try{
	const fetch=await axios.post('https://devnew.qdobamobile.app/api/v1/security/token', employee)
  const info =await fetch.data
  console.log(info)
  this.setState({
    accTok:info.accessToken,
    cusId:info.customerId
  })
  console.log(this.state.accTok)
  console.log(this.state.cusId)
  }
  catch(e){
      console.log('error',e.message)
  }
  try {
    //console.log(this.state.cusId)
    const response = await axios.get(`https://devnew.qdobamobile.app/api/v1/query/customer/${this.state.cusId}`,{ headers: {"authToken" : this.state.accTok} });
    this.setState({
      data:response.data
    })
    console.log(this.state.data);
    return(this.setState({
      loading:true
    }));
    
  } 
  catch (error) {
    console.error(error);
  }
}

  signUp(e){
    e.preventDefault()  
    this.setState({
      signUp:true
    })
    
  }
  handleBack(e){
  e.preventDefault()
  return(
  this.setState({
    loading:false
  }))
  }
  history_handler(e){
    e.preventDefault()
    this.setState({
      ohistory:true,
      order:false
    })
  }
  async handleRet(){
    try {
      //console.log(this.state.cusId)
      const response = await axios.get(`https://devnew.qdobamobile.app/api/v1/query/customer/${this.state.cusId}/order/history`,{ headers: {"authToken" : this.state.accTok} });
      this.setState({
        history:response,
       
      })
      console.log(this.state.history.data.results);
      this.setState({
        resultSet:this.state.history.data.results,
       
      })
    
    } 
    catch (error) {
      console.error(error);
    }
    
    let items=[]
    let amt=[]
    let indi=""
    for(indi of this.state.resultSet){
      items.push(indi.lineItems[0].name)
      amt.push(indi.taxAndTotal.totalAmt.amount)
      //  return(console.log(items.lineItems[0].name))
    }
    console.log(items)
    this.setState({
      items:items,
      amt:amt,
      loading:false,
      order:true,
    })

  }
   
  render(){
    // if(this.state.loading){
    //   console.log("in redirect now")
    //   return(<Login information={this.state.data}/>,<Redirect to='/Login'/>)
    // }
    if(this.state.ohistory){
return (<div>
    <div className="dim_overlay"></div>
    <header className="nav_bar">

          <div className="background_bar" ><img className="qdoba_logo_horizontal" src={qdoba}/></div>
    </header>
    <div className="secondary_page">
      <div className="order_hisytory_container">
      <section className="order_history_header_container">
          <div className="order_history_header_constraint">
              <h1 className="order_history_header qdoba_h1">
                  Order Details
                </h1>
          </div>
          {/* next page   */}
          
      </section>
      <div className="order_history_content_constraint">
            <section className="order_history_content_container">
              <h2 className="link_card_header">July 8@5:00</h2>
              <h3 className="prev_ord_sub_heading_q_h2">Items</h3>
            <div>
              <h3 className="link_card_secondary item_header"> Burrito Chicken<span className="quantity">  x1</span></h3>
              <p className="order_detail_description">Chicken, Grilled Steak, Flour Tortilla, Brown Rice, No Beans, Salsa Verde, 3-Cheese Queso</p>
            </div>
            <div className="prev_orders_total">
            <h4 className="subtotal">SUBTOTAL<span>$10.80</span></h4>
            <h4 className="subtotal">TAX<span>$0.65</span></h4>
            <h2 className="total">TOTAL<span>$11.45</span></h2>
            
            </div>
            </section>
            <section className="previous-orders-location ">
            <h3 className="prev_ord_sub_heading_q_h2">Location</h3>

            <ul className="prev-orders-list">
              <li>1998 W. Bonfils Lane</li>
              <li>LakeWood</li>
              <li>789-1293-12</li>
            </ul>
            <button className="order_history_reorder_button q_main_button" >Reorder</button>
            </section>

          </div>
      </div>
      </div>
    </div>)
    }
    
    if(this.state.signUp){
     return <Redirect to='/Signup'/>
    }
    if(this.state.loading){
      return(
      <div>
          <div className="App-background">
            <h1>User Details:</h1>
            <p>Name : {this.state.data.firstName}</p>
            <p>LastName : {this.state.data.lastName}</p>
            <p>Email : {this.state.data.email}</p>
            <p>Birthday : {this.state.data.birthday}</p>
            <p>Loyalty Number:{this.state.data.loyaltyCards}</p>
            <button className="App-button-3" onClick={this.handleBack}>Back</button>
            <button className="App-button-5" onClick={this.handleRet} >Retrieve History</button>
          </div>
          </div>


      )
      }
      if(this.state.order){
        return(
        <div>
    <div className="dim_overlay"></div>
    <header className="nav_bar">

          <div className="background_bar" ><img className="qdoba_logo_horizontal" src={qdoba}/></div>
    </header>
    <div className="secondary_page">
      <div className="order_hisytory_container">
      <section className="order_history_header_container">
          <div className="order_history_header_constraint">
              <h1 className="order_history_header qdoba_h1">
                  Order History
                </h1>
          </div>
      </section>
      <section className="order_history_container">
      <h2 className="q_h2 order_history_subheader">Past Orders</h2>
     { this.state.items.map (item=><section className="link_card">
            <div >
                <h2 className="link_card_header">{item}</h2> 
              </div>
               <div>
                <p className="link_card_secondary">Burrito Chicken</p>
                <button className="link_card_arrow" onClick={this.history_handler}>></button>
              </div> 
          </section>)}
      </section>
      </div>
      </div>
    </div>)
      
      }
   
    return (
      <div>
          <form  className="App-background">
          <h1>Logging in</h1>
          <label className="App-label">User Name:</label><input 
          className="App-textinput"
          type="text" 
          placeholder="username" 
          name="username" 
          onChange={this.handleChange}/>
          <br/>
          <label className="App-label">Password:</label><input 
          className="App-textinput"
          type="password" 
          placeholder="password" 
          name="password" 
          onChange={this.handleChange}/>
          <br/><br/>
          <button onClick={this.handleSubmit} className="App-button">Log In</button>
          <button className="App-button-1" onClick={this.signUp}>Sign Up</button>
       </form>
             
    </div>
    
     );
  }
}

export default Mainform;
