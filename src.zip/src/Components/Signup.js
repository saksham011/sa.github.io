import React from 'react'
import {Link} from 'react-router-dom'
class Signup extends React.Component{
    constructor(props){
        super(props)
        this.state={
            firstName:"",
            lastName:"",
            email:"",
            confMail:"",
            mob:"",
            month:"",
            day:"",
            pass:"",
            confPass:"",
            back:false
        }
        this.handleChange=this.handleChange.bind(this)
        this.handleSubmit=this.handleSubmit.bind(this)
        // this.handleBack=this.handleBack.bind(this)
    }
    handleChange(event){
        const {name,value}=event.target
        this.setState({
            [name]:value
        })

    }
    // handleBack(e){
    //    return  <Link to ='/'>Back</Link>
    // }
    handleSubmit(e){
       e.preventdefault() 
    }
    render(){
       
       
        return(
            <div>
               <form className="App-background-1">
                   <h1>Sign Up </h1>
                    <label className="App-label">Last Name:-</label><input className="App-textinput" placeholder="Last Name" type="text" name="lastName" value={this.state.lastName} onChange={this.handleChange}/><br/>
                    <label className="App-label">First Name:-</label><input className="App-textinput" placeholder="First Name" type="text" name="firstName" value={this.state.firstName} onChange={this.handleChange}/><br/>
                    <label className="App-label">Email Address:-</label><input className="App-textinput" placeholder="Email" type="text" name="email" value={this.state.email} onChange={this.handleChange}/><br/>
                    <label className="App-label">Confirm Email Address:-</label><input className="App-textinput" placeholder="Email" type="text" name="confEmail" value={this.state.confEmail} onChange={this.handleChange}/><br/>
                    <label className="App-label">Phone Number:-</label><input className="App-textinput" placeholder=" Your Mobile no." type="text" name="mob" value={this.state.mob} onChange={this.handleChange}/><br/>
                    Month:{<select className="App-select" name="month" value={this.state.month} onChange={this.handleChange}> 
                    <option value="">Select month</option>
                    <option value="January"> January</option>
                    <option value="February">February</option>
                    <option value="March"> March</option>
                    <option value="April">April</option>

                    <option value="May">May</option>
                    <option value="June">June</option>
                    <option value="July">July</option>
                    <option value="August">August</option>
                    <option value="September">September</option>
                    <option value="October">October</option>
                    <option value="November">November</option>
                    <option value="December">December</option>
                    </select>}
                    <br/>
                    Day:{
                        <select className="App-select-1" name="day" value={this.state.day} onChange={this.handleChange}>
                        <option value="">Select day</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        </select>
                    }<br/>
                    <label className="App-label">Password:-</label><input className="App-textinput" type="password" name="pass" value={this.state.pass} onChange={this.handleChange}/><br/>
                    <label className="App-label">Confirm Password:-</label><input className="App-textinput" type="password" name="confPass" value={this.state.confPass} onChange={this.handleChange}/><br/><br/>

                <button className='App-button-2' onClick={this.handleSubmit}>Next</button>
                {/* <button className='App-button-3' onClick={<Link to='/'></Link>}>Back</button> */}
                <Link className='App-button-4' to='/'>Back</Link>
                </form>
                
            </div>
        )
    }
}
export default Signup


