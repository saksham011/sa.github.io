 import React from 'react';
import {Route,Switch} from 'react-router-dom'
import Login from './Components/Login'
import Mainform from './Components/Mainform'
import Signup from './Components/Signup'
class App extends React.Component {
  render(){
    return (
   
      <div>
        <Switch>
          <Route exact path="/" component={Mainform}></Route>
          <Route exact path="/Login" component={Login}></Route>
          <Route exact path='/Signup' component={Signup}></Route>
          </Switch>
      </div>
      
    );
  }
 
}

export default App;
