import * as firebase from 'firebase'

var firebaseConfig = {
    apiKey: "AIzaSyBzUYk_u_cpEaWEUVOd73ZeMhNroYhZLQQ",
    authDomain: "new-app-86cd2.firebaseapp.com",
    databaseURL: "https://new-app-86cd2.firebaseio.com",
    projectId: "new-app-86cd2",
    storageBucket: "new-app-86cd2.appspot.com",
    messagingSenderId: "863916537754",
    appId: "1:863916537754:web:9b30550f116a246e16ac23",
    measurementId: "G-771WNB2XZ7"
  };

firebase.initializeApp(firebaseConfig)

const firebaseDB=firebase.database()
const googleAuth=new firebase.auth.GoogleAuthProvider()


export {firebaseDB,googleAuth,firebase}
//.set()->for posting the data
// .update()->for updating the object
// .remove()->for deleting the data
//.once=> for retrieving the data and runs only once and uses promises
// firebase.database().ref().once('value')
// .then((snapshot)=>{
//     console.log(snapshot.val())
// })
// .then((e)=>{
//     console.log(e)
// })
//.on=> doesn't uses promise rather a callback and whenever 
//there is a changein the database in firebase it sends the new data 


//'value'-gets the value
//'child_removed'-listening when something gets removed 
//'child_changed'-listening to chnages to child changes
//'child added'-listening to child added but return the entire root directory
// firebaseDB.ref().on('child_added',(snapshot)=>{
//     console.log(snapshot.key,snapshot.val())
// })

//.push for pushing arrays 
// firebaseDB.ref().push({
//     id:5,
//     name:'dumbledore',
//     age:85
// })

// firebaseDB.ref().orderByChild('name')..once('value')
// .then((snapshot)=>{
//     const users=[];
//     snapshot.forEach((childSnapshot)=>{
//         users.push({
//             id:childSnapshot.key,
//             realid:childSnapshot.val().id,
//             name:childSnapshot.val().name,
//             age:childSnapshot.val().age
//         })
//     })
//     console.log(users)
// })


// firebaseDB.ref().orderByChild('id').once('value')
// .then((snapshot)=>{
//     console.log(snapshot.val())
// })


//A proimise doesn't responds with response in 
//firebase rather than it responds with snapshot

